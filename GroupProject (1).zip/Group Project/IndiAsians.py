from random import *

CurrentRound = 0

def getMove( myScore, myBalls, myDucksUsed, myMovesSoFar,
             oppScore, oppBalls, oppDucksUsed, oppMovesSoFar ):
    global CurrentRound
    
    CurrentRound += 1
    
    if len(myMovesSoFar) == 0: ###FIRST MOVE IS THROW
        return "THROW"

    if myBalls >= 3: ### IF WE HAVE 3 OR MORE BALLS, WE THROW
        return "THROW"
    
    elif myBalls == 0 and oppBalls == 0: #### IF BOTH PLAYERS HAVE NO BALLS, RELOAD
        return "RELOAD"

    elif myMovesSoFar[len(myMovesSoFar) - 1] == "DUCK" and myMovesSoFar[len(myMovesSoFar) - 2] == "DUCK": ### IF OUR LAST TWO MOVES WERE DUCK, WE CHECK THESE STATEMENTS
        if myBalls >= 1: ##IF WE HAVE BALLS, WE GIVE THROW A 66% CHANCE AND RELOAD A 33% CHANCE
            return choice(["THROW" , "RELOAD", "THROW"])

        else: ### IF WE DON'T HAVE BALLS, WE JUST
            return "RELOAD"


    elif CurrentRound >= 26 and 0 < myBalls <= 4: ### IF THERE ARE 4 ROUNDS LEFT, THROW ONLY
        return "THROW"

    elif myBalls > 0 and oppBalls == 0: ### IF THE OPP HAS NO BALLS AND WE DO HAVE BALLS, CHECK THESE STATEMENTS
        if oppDucksUsed == 5:
            return "THROW"

        else:
            return choice(["THROW" , "RELOAD", "THROW"])

    elif oppMovesSoFar[len(oppMovesSoFar)-1] == "RELOAD" and oppMovesSoFar[len(oppMovesSoFar)-2] == "RELOAD" and myDucksUsed < 5: ### CHECKS IF THE OPP LAST 2 MOVES WERE RELOAD
        return choice(["DUCK" , "RELOAD", "DUCK"]) ## THE OPP HAS A HIGH CHANCE OF THROWING SO WE LET DUCK HAVE A 66% CHANCE AND ALSO LET RELOAD HAVE A 33% CHANCE OF HAPPENING
        

    elif  oppMovesSoFar[len(oppMovesSoFar)-1] == "DUCK" and oppMovesSoFar[len(oppMovesSoFar)-2] == "RELOAD" : #IF THE LAST 2 MOVES FROM THE OPP WERE RELOAD AND THEN DUCK, CHECK THESE STATEMENTS
        if myDucksUsed < 5 and oppBalls >= 2: ### IF WE DIDN'T USE OUR FIVE DUCKS AND THE OPP HAS MORE OR EXACTLY 2 BALLS, WE DUCK
           return "DUCK"

        elif myDucksUsed == 5 and myBalls > 0: ### IF WE HAVE USED ALL OUR DUCKS AND WE HAVE BALLS LEFT, WE JUST THROW
            return "THROW"

        else:
            return "RELOAD" ### IF ALL ELSE FAILS, WE RELOAD

    elif oppMovesSoFar[len(oppMovesSoFar)-1] == "DUCK" and oppMovesSoFar[len(oppMovesSoFar)-2] == "DUCK": ### IF OPP'S LAST 2 MOVES WERE DUCK, CHECK THESE STATEMENTS
        if myDucksUsed < 5 and oppBalls >= 2: ### IF WE DIDN'T USE OUR FIVE DUCKS AND THE OPP HAS MORE OR EXACTLY 2 BALLS, WE DUCK
            return "DUCK"

        elif myDucksUsed == 5 and myBalls > 0: ### IF WE HAVE USED ALL OUR DUCKS AND WE HAVE BALLS LEFT, WE JUST THROW
            return "THROW"

        else:
            return "RELOAD" ### IF ALL ELSE FAILS, WE RELOAD


    elif oppMovesSoFar[len(oppMovesSoFar)-1] == "THROW" and oppMovesSoFar[len(oppMovesSoFar)-2] == "THROW" and oppBalls != 0: ### IF THE OPPS LAST 2 MOVES WERE THROW AND THEY STILL HAVE BALLS LET, CHECK THESE STATEMENTS
        if myDucksUsed < 5 and oppScore == 2 and myBalls != 0: ### IF WE HAVENT USED ALL OUR DUCKS, HAVE BALLS LEFT, AND THE OPP SCORE IS 2, EITHER THROW OR DUCK
            return choice(["THROW","DUCK"])

        elif myDucksUsed < 5 and oppScore == 2 and myBalls == 0: ### IF WE HAVENT USED ALL OUR DUCKS, DON'T HAVE BALLS LEFT, AND THE OPP SCORE IS 2, WE DUCK
            return "DUCK"
        
        elif myDucksUsed < 5 and oppScore != 2 and myBalls != 0: ### IF WE HAVENT USED ALL OUR DUCKS, HAVE BALLS LEFT, AND THE OPP SCORE ISN'T 2, WE THROW
            return "THROW"
        
        elif myDucksUsed < 5 and oppScore != 2 and myBalls != 0 and oppBalls <= 2: ###IF WE HAVE DUCKS, DON'T HAVE BALLS LEFT, AND THE OPP SCORE ISN'T 2, WE EITHER THROW (66% CHANCE) OR RELOAD (33% CHANCE) 
            return choice(["THROW", "THROW", "RELOAD"])

        else:
            return "RELOAD" #IF ALL ELSE FAILS, WE RELOAD
    
    elif oppMovesSoFar[len(oppMovesSoFar)-1] == "RELOAD" and oppMovesSoFar[len(oppMovesSoFar)-2] == "DUCK" and myDucksUsed < 5 and myBalls != 0: ### IF THE OPPS LAST MOVES WERE DUCK THEN RELOAD AND WE HAVE DUCKS AND BALLS, CHECK THESE STATEMENTS
        if oppBalls != 0: ### IF OPP HAS BALLS, WE DUCK
            return "DUCK"
        
        elif myBalls>=3: ### IF OUR BALLS ARE MORE THAN OR EQUAL TO 3, WE THROW
            return "THROW"

        else:
            return "RELOAD" ### IF ALL ELSE FAILS, WE RELOAD

    elif oppMovesSoFar[len(oppMovesSoFar)-1] == "THROW" and oppMovesSoFar[len(oppMovesSoFar)-2] == "RELOAD" and oppBalls > 0: ### IF OPPS LAST MOVES WERE RELOAD THAN THROW AND THEY HAVE BALLS LEFT, CHECK THESE STATEMENTS
        if myDucksUsed < 5: ### IF WE HAVEN'T USED ALL OUR DUCKS, WE DUCK
             return "DUCK"

        elif myBalls > 0: ### IF WE HAVE BALLS, WE THROW
            return "THROW"

        else:
            return "RELOAD" ###IF ALL ELSE FAILS, WE RELOAD

    elif oppMovesSoFar[len(oppMovesSoFar)-1] == "RELOAD" and oppMovesSoFar[len(oppMovesSoFar)-2] == "THROW" and oppBalls > 0: ### IF THE OPPS LAST 2 MOVES WERE THROW THAN RELOAD, CHECK THESE STATEMENTS
        if myDucksUsed < 5 and oppBalls >= 1: ### IF WE HAVE DUCKS AND THE OPP HAS BALLS, WE DUCK
             return "DUCK"

        elif myBalls > 0: ### IF WE HAVE BALLS, WE THROW
            return "THROW"

        else:
            return "RELOAD" ### IF ALL ELSE FAILS, WE RELOAD
        
    elif oppMovesSoFar[len(oppMovesSoFar)-1] == "THROW" and oppMovesSoFar[len(oppMovesSoFar)-2] == "DUCK" and oppBalls > 0: #### IF THE OPPS LAST 2 MOVES WERE DUCK THAN THROW, CHECK THESE STATEMENTS
        if myDucksUsed < 5 and oppBalls >= 1: ### IF WE HAVE DUCKS AND THE OPP HAS BALLS, WE DUCK
             return "DUCK"

        elif myBalls > 0: ### IF WE HAVE BALLS, WE THROW
            return "THROW"

        else:
            return "RELOAD" ### IF ALL ELSE FAILS, WE RELOAD

    elif oppMovesSoFar[len(oppMovesSoFar)-1] == "DUCK": ###IF THE OPPS LAST MOVE WAS DUCK, WE CHECK THESE STATEMENTS
        if myBalls > 0: ### IF WE HAVE BALLS, WE THROW
            return "THROW"

        else:
            return "RELOAD" ### IF ALL ELSE FAILS, WE RELOAD
    

    elif oppBalls >= 2 and oppScore == 2: ### IF THE OPP HAS 2 OR MORE BALLS AND THEIR SCORE IS 2, CHECK THESE STATEMENTS
        if myDucksUsed <= 4: ### IF WE HAVE USED 4 OR LESS DUCKS, WE DUCK (I don't know why this isn't "myDucksUsed < 5" but whatever, it doesn't matter)
            return "DUCK"

        elif myBalls >= 1: ### IF WE HAVE 1 OR MORE BALLS, WE THROW (Also, I don't know why this isn't "myBalls > 0" but it still works)
            return "THROW"

        else:
            return "RELOAD" ###IF ALL ELSE FAILS, WE RELOAD

    elif oppMovesSoFar[len(oppMovesSoFar)-1] == "RELOAD" and oppMovesSoFar[len(oppMovesSoFar)-2] == "RELOAD" and myDucksUsed < 5: ### CHECKS IF THE OPP LAST 2 MOVES WERE RELOAD, THEY ARE HIGHLY LIKELY TO THROW SO WE DUCK
        if oppMovesSoFar[len(oppMovesSoFar)-3] == "RELOAD": ### IF THE OPP 3RD LAST MOVE WAS ALSO RELOAD, CHECK THESE STATEMENTS
            if myBalls >= 1: ##IF WE HAVE BALLS, WE THROW
                return "THROW"
            elif myDucksUsed < 5: ### IF WE CAN'T THROW AND WE GOT DUCKS LEFT, WE DUCK
                return "DUCK"

            else:
                return "RELOAD" ### IF ALL ELSE FAILS, WE GOTTA RELOAD. 

        elif myDucksUsed < 5: ### IF WE GOT DUCKS, YOU BET WE GONNA DUCK
            return "DUCK"

        else:
            return "RELOAD" ### IF ALL ELSE FAILS, WE ARE GONNA RELOAD.
        
        
    else: ###CHECK THESE STATEMENTS IF THE OTHER BOT IS DOING SOME CRAZY STUFF THAT WE DIDN'T PREDICT
        if myBalls== 0: ### OH MAN, IF WE DON'T GOT ANY BALLS, WE GOTTA CHECK THESE STATEMENTS
            if myDucksUsed == 5: ### IF WE DON'T HAVE DUCKS, WE HAVE TO RELOAD
                return "RELOAD"

            else: ### IF WE HAVE DUCKS, WE PICK EITHER RELOAD (66% CHANCE) OR DUCK (33% CHANCE)
                return choice(["RELOAD","RELOAD","DUCK"])
            
        else: ## IF WE GOT BALLS, CHECK THESE STATEMENTS
            if myDucksUsed == 5: ### IF WE DON'T HAVE DUCKS, WE EITHER THROW (33% CHANCE) OR RELOAD (66% CHANCE)
                return choice(["THROW", "RELOAD", "RELOAD"])

            else:### IF WE HAVE DUCKS, WE EITHER THROW (25% CHANCE), RELOAD (50% CHANCE) OR DUCK (25% CHANCE)
                return choice(["THROW", "RELOAD", "RELOAD", "DUCK"])
