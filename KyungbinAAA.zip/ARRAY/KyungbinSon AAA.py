from tkinter import *
from time import *
from random import *
from math import*
tk = Tk()
s = Canvas(tk, width=1000, height=700, background="black")
s.pack()


s.create_rectangle(120,0,870,660, fill="gray25")

##STARS 
for n in range(800):
    x= randint(0,1000)
    y= randint(0,600)
    size= randint(1,2)
    s.create_oval(x,y,x+size, y+size, fill="white",outline="white")
    
s.create_arc( 390,20, 210, 460, start=0, extent= 180, fill="saddle brown",outline="saddle brown")

s.create_rectangle(210,240,390, 600, fill="saddle brown",outline="saddle brown")
s.create_rectangle(360,240,230, 600, fill="black",outline="black")
s.create_arc(390,30,225,460,start=0, extent= 180, fill="black",outline="black")
s.create_rectangle(360,30,390,620, fill="sienna4",outline="sienna4")
s.create_rectangle(570,30,600,600, fill="sienna4",outline="sienna4")

mountainColours = ["PaleTurquoise1","CadetBlue1","DarkSlateGray1","light cyan","azure","LightBlue4"]
for mountainnumbers in range(0,10):
    mountainx = randint(210,275)
    mountainy = 600

    s.create_polygon(mountainx,mountainy,mountainx + randint(30,50),mountainy - randint(50,150), mountainx + randint(75,100),mountainy,mountainx,mountainy,fill = choice(mountainColours))

s.update()
# red carpet


s.create_polygon(120,660,210,600,750, 600,840, 660,870, 800,120,800, fill="brown")
#s.create_rectangle(120,660,810,800, fill="yellow")


##WINDOW LINES

s.create_line(270,60,270,600, fill="white",width=3)
s.create_line(330,60,330,600, fill="white",width=3)




##SECOND WINDOW
s.create_arc(590,27,765, 500,star=0, extent= 180, fill="saddle brown", outline="saddle brown")
s.create_rectangle(600,240,765, 600, fill="saddle brown", outline="saddle brown")
s.create_rectangle(600,240,750, 600, fill="black")
s.create_arc(597,30,750,600, start=0,extent=180, fill="black")


s.create_rectangle(390,270,570,660, outline="NavajoWhite3",fill="NavajoWhite3")
s.create_rectangle(390,270,570,280, fill="NavajoWhite2",outline="NavajoWhite2")
s.create_arc(541,300,420,500, start=0, extent=180, fill="royalblue4",outline="royalblue4")
s.create_rectangle(420, 360, 540, 650, fill="royalblue4",outline="royalblue4")
s.create_rectangle(0,0,120,800, fill="tan4",outline="tan4")


s.create_oval(420,540,510,560, fill="PaleVioletRed",outline="PaleVioletRed")
s.create_rectangle(460,560,470,650,fill="PaleVioletRed",outline="PaleVioletRed")
s.create_polygon(485,270,450,330,420, 360,420,390,425,450,420,510,429,600,420,640,390,660,390,270,480,270, fill="red")
s.create_line(450,650,475,650, fill="PaleVioletRed",width=8)
s.create_polygon(435,545,445,480,450,450,475,420,480,420,490,450,492,480,500,545, fill="lightblue",outline="black",smooth="true")
s.create_rectangle(435,535,500,540, fill="brown",outline="brown")
s.create_oval(420,540,510,560, fill="PaleVioletRed",outline="PaleVioletRed")





for mountainnumbers in range(0,10):
    mountainx = randint(590,665)
    mountainy = 600

    s.create_polygon(mountainx,mountainy,mountainx + randint(30,50),mountainy - randint(50,150), mountainx + randint(75,100),mountainy,mountainx,mountainy,fill = choice(mountainColours))




##POLES AND THE FENCE THINGY 
s.create_rectangle(0,540,125,550,fill="goldenrod1",outline="goldenrod1")
s.create_rectangle(0,570,125,580, fill="goldenrod1",outline="goldenrod1")
s.create_rectangle(870,0,1000,800, fill="tan4",outline="tan4")
s.create_rectangle(870,540,1000,550,fill="goldenrod1",outline="goldenrod1")
s.create_rectangle(870,570,1000, 580, fill="goldenrod1",outline="goldenrod1")
s.create_polygon(870,300,820,310,820,340,870, 330, fill="sandybrown")
s.create_polygon(750,340,720,330,720,800,750, 800, fill="salmon4", outline="salmon4")
s.create_polygon(690,360,690,340,720,330,720,355,690,360, fill="sandy brown",outline="black" )
s.create_rectangle(720,370, 690, 800, fill="tan2", outline="tan2")
s.create_rectangle(870,360,820, 800, fill="tan2", outline="tan2")
s.create_polygon(120,300,160,320,163,340,120,335, fill="sandy brown")
s.create_rectangle(220,360,240,800,fill="salmon4",outline="black")
s.create_rectangle(120,360,160, 800, fill="tan2",outline="tan2")
s.create_rectangle(240,360,270,800, fill="tan2",outline="tan2")
s.create_polygon(870,330,690,360,690,390,870,360, fill="sandy brown")
s.create_polygon(120,330,270,360,270,390,120, 360, fill="sandy brown")
s.create_polygon(240,330,270,340,270,360,240,355, fill="sandy brown",outline="black")
s.create_polygon(240,330,230,335,220,340,220,350,240, 355, fill="salmon4", outline="black")



##STEM OF TULIPS

s.create_line(475,535,465,470,fill="green",width=4)


s.create_oval(455,460,467,470, fill="red",outline="red")
s.create_polygon(465,470,470,455,475,455,455,460, fill="red")
s.create_polygon(475,510,480,490,485,499,480,492,475,525, fill="green")
s.create_polygon(470,500,465,495,450,500,475,503, fill="green")
s.create_polygon(474,270,483,300,510,360,560,430,510,510,495,600,515,660,570,650,570,270, fill="red")
s.create_line(520,480,570,510, fill="yellow",width=7)
s.create_line(425,510, 390, 510, fill="yellow",width=7)


## WINDOWS
x=225
y=180
x2=360
y2=180
for i in range(4):
    s.create_line(x,y,x2,y2,fill="white",width=3)
    y=y+50
    y2= y2+50



x=270
y=390
x2=360
y2=390

for i in range(4):
    s.create_line(x,y,x2,y2,fill="white",width=3)
    y=y+50
    y2=y2+50


x= 600
y=180
x2=750
y2=180

for i in range(4):
    s.create_line(x,y,x2,y2, fill="white",width=3)
    y=y+50
    y2=y2+50

x=600
y=390
x2=690
y2= 390

for i in range(4):
    s.create_line(x,y,x2,y2, fill="white",width=3)
    y=y+50
    y2=y2+50

s.create_line(637, 60,637, 600, fill="white",width=3)
s.create_line(700,50, 700,600, fill="white",width=3)




#candles
#chandelier body

s.create_line(500,0, 500, 150, fill="grey",width=4,smooth="true")
s.create_rectangle(490,0, 510,30, fill="grey")
s.create_line(500,150,490,180,370,150,340,120,fill="grey",smooth="true",width=2)
s.create_line(500,150,590,180,640,150,670,120, fill="grey",smooth="true",width=2)
s.create_line(500,150,490,150,460,170,460,180,430, 100, fill="grey",smooth="true",width=2)
s.create_line(500,150,520,150,540,180,570,120,570, 60, fill="grey",smooth="true",width=2)
s.create_line(500,150,530,160,430,150,400,120, fill="grey",smooth="true",width=2)
s.create_line(500,150, 530,160, 570,150,600,120, fill="grey",smooth="true",width=2)
#bottom
x1= [430,570,400,600,340,670]
x2= [420,555,385,585,320,655]
x3= [455,575,415,615,355,690]
y1= [100,100,120,120,120,120]
y2= [90,80,110,110,110,110]
y3= [90,80,110,110,110,110]
for i in range(6):
    s.create_polygon(x1[i],y1[i],x2[i],y2[i],x3[i],y3[i], fill="grey")
    

#wax body

x1= [440,580,410,610,350,680]
x2=[420,560,390,590,330,660]
y1=[90,80,110,110,110,110]
y2= [50,50,70,70,70,70]

for i in range(6):
    s.create_rectangle(x1[i],y1[i],x2[i],y2[i], fill="white",outline="white")
s.create_rectangle(120,650, 820, 800, fill="wheat3")


##pic= PhotoImage(file="lunkey.gif")
##s.create_image(400,400, image=pic)
##s.update()
#fire
numflames =6
numDebris= 45
x1= [340,400,430,570,600,670]
x2= [343,403,430,570,603,673]
y1=[70,70,50,50,70,70]
y2= [65,65,50,50,65,65]
drawings= []
xx= []
yy= []
xx2= []
yy2=[]
a= []
eyes1= []
eyes2= []
inside= []
inside2= []
eyebrows= []
eyebrows1=[]
smile=[0]
rectangle= [0]
rectangle1= [0]
bottom= []
fire= []
arm= []
arm1=[]
x=[]
y=[]
r= []
angles= []
debris= []
xxx =[]
yyy= []
debris2 =[]
angles2= []
rr= []
rrr= []
x4= []
y4= []
debris3= []
angles3= []
debris4= []
xx5= []
yy5= []


for i in range(0,numDebris):
    x.append(randint(290,320))
    y.append(randint(200,220))
    xxx.append(randint(300,320))
    yyy.append(randint(180,220))
    xx5.append(randint(670,690))
    yy5.append(randint(200,220))
    x4.append(randint(640,660))
    y4.append(randint(450,470))
    debris.append(0)
    debris2.append(0)
    debris3.append(0)
    debris4.append(0)
    angle= randint(1,600)
   
    r.append(randint(-5,9))
    radianAngle = 3.14159*angle/180
    angles.append(radianAngle)

for i in range(0,numflames):
    drawings.append(0)

for i in range(0, 1):
    xx.append(randint(100,200))
    yy.append(randint(50,61))
    a.append(0)
    eyes1.append(0)
    eyes2.append(0)
    inside.append(0)
    inside2.append(0)
    eyebrows.append(0)
    eyebrows1.append(0)
    smile.append(0)
    rectangle.append(0)
    rectangle1.append(0)
    bottom.append(0)
    fire.append(0)
    arm.append(0)
    arm1.append(0)

   
for k in range(100): #in every frame of the animation...
    
    for i in range(0,numflames): #for each flame...
        y1[i] = y2[i] - randint( 10, 15 ) #Sets the top edge of this flame randomly
        drawings[i] = s.create_oval( x1[i], y1[i], x2[i], y2[i], fill="yellow",outline="yellow") #Makes the current flame
    ##FIREWORK

    for i in range(0,1):
        xx[i]= xx[i]+ 6
        yy[i]= yy[i]+10*sin(0.2*(k-3*i)) 

##        a[i]= s.create_rectangle(xx[i],yy[i],xx[i]+50,yy[i]+70, fill="white",outline="white")
##        eyes1[i]= s.create_oval(xx[i]+10, yy[i]+15, xx[i]+20, yy[i]+35,fill="white", outline="black")
##        eyes2[i]=s.create_oval(xx[i]+30, yy[i]+15, xx[i]+40, yy[i]+35, fill="white", outline="black")
##        inside[i]= s.create_oval(xx[i]+10, yy[i]+26, xx[i]+20, yy[i]+40, fill="black")
##        inside2[i]= s.create_oval(xx[i]+30, yy[i]+26, xx[i]+40, yy[i]+40, fill="black")
##        eyebrows[i]= s.create_line(xx[i]+20, yy[i]+2, xx[i]+5, yy[i]+20, fill="black",width=3)
##        eyebrows1[i]= s.create_line(xx[i]+50, yy[i]+19, xx[i]+30, yy[i]+5, fill="black",width=3)
##        smile[i]= s.create_line( xx[i]+30, yy[i]+50, xx[i]+10, yy[i]+45, fill="black")
##        rectangle[i]= s.create_rectangle(xx[i]+55, yy[i]+70, xx[i]-5, yy[i]+120, fill="yellow",outline="yellow")
##        rectangle1[i]= s.create_rectangle(xx[i]+20, yy[i]+250, xx[i]+25, yy[i]+120, fill="yellow",outline="yellow")
##        bottom[i]= s.create_oval(xx[i]-10,yy[i]+230, xx[i]+60, yy[i]+250, fill="yellow",outline="yellow")
##        fire[i]= s.create_polygon(xx[i]+30,yy[i]-30,xx[i]+50,yy[i],xx[i]+3,yy[i], fill="orange")
##        arm[i]= s.create_rectangle(xx[i]+55, yy[i]+96,xx[i]+140, yy[i]+90, fill="yellow",outline="yellow")
##        
    s.update()
    sleep(0.03)    
                                              

    for i in range(0,numflames): #Erases all 10 flames
        s.delete( drawings[i] )

    for i in range(0,1):
        s.delete(a[i],eyes1[i],eyes2[i],inside[i],inside2[i],eyebrows[i],eyebrows1[i],smile[i],rectangle[i],rectangle1[i],bottom[i],fire[i],arm[i])

   # for i in range(0, numDebris):
       # s.delete( debris[i],debris2[i] )



for f in range(10):            
    for i in range( 0, numDebris ):
    
        debris[i] = s.create_line( x[i], y[i], x[i] +9, y[i] +9, fill = "red" )

        x[i] = x[i] + r[i] * cos( angles[i] )
        y[i] = y[i] - r[i] * sin( angles[i] ) + .07*f**2
        

        debris2[i] = s.create_line( xxx[i], yyy[i], xxx[i] - 5, yyy[i] -5, fill = "red" )

        xxx[i] = xxx[i] + r[i] 
        yyy[i] = yyy[i] - r[i] * sin( angles[i] ) + .07*f**2


    
        debris4[i]= s.create_line(xx5[i],yy5[i],xx5[i]+9,yy5[i]+2, fill="purple1")
        xx5[i] = xx5[i] + r[i] * cos( angles[i] )
        yy5[i] = yy5[i] - r[i] * sin( angles[i] ) + .07*f**2        

    s.update()
    sleep(0.04)


for f in range(10):            
    for i in range( 0, numDebris ):
    
        debris3[i] = s.create_line( x4[i], y4[i], x4[i] +9, y4[i] +9, fill = "skyblue" )

        x4[i] = x4[i] + r[i] * cos( angles[i] )
        y4[i] = y4[i] - r[i] * sin( angles[i] ) + .08*f**2
        
    s.update()
    sleep(0.04)

spacing = 30#try changing this
for x in range(0, 1000, spacing): 
    s.create_line(x, 20, x, 1000, fill="yellow")
    s.create_text(x, 10, text=str(x), font="Times 10", anchor = N)


for y in range(0, 1000, spacing):
    s.create_line(30, y, 1000, y, fill="yellow")
    s.create_text(5, y, text=str(y), font = "Times 10", anchor = W, fill="yellow")

