from tkinter import *
from time import *
from math import *
from random import *


##NEMO##  
master = Tk()
s = Canvas( master, width = 600, height = 600, background = "turquoise")
s.pack()

ballspeed=-5
yballspeed=-4
xx=500
yy=450
xwall= 100

for f in range (20):
    d = randint(30,80)
    h = f*d
    w = randint(10,15)
    l = randint(100,400)
    for a in range (0,l):
        y2 = 800-1.5*a
        x2 = h + 10*sin(0.05*a )
        s.create_oval(x2,y2,x2+w,y2+w,fill="dark olive green",outline="dark olive green")
s.update()

#bubbles


for f in range(30):
    x= randint(0, 600)
    y= randint(0, 600)
    width= randint(0,50)
    height= randint(0,50)
    s.create_oval(x,y,x+width, y+width, fill="deepskyblue", outline="deepskyblue")

s.update()


#ground

s.create_polygon( 0,540,90,530,210,540,390,540,450,550,600,540,600,600,0,600, fill="sandybrown", outline="sandybrown")

#rocks

s.create_polygon(60,570,90,540,120,535,120,540,125,570, fill="grey",outline="grey",smooth="true")
#fish


for f in range(200):    
    xx= xx+ballspeed
    yy= yy+yballspeed  
    x2= xx+180
    y2= yy+110
    if xx<=xwall:
        text1 = s.create_text (300,300, text = "OH NO!!! I DON'T WANT TO DIE", font = "Calibri 30", fill = "red")
        ballspeed=-1*ballspeed*2
        yballspeed=-1*yballspeed*2
    
    tailx= xx+200
    taily= yy+50
    linex= xx+35
    liney=yy+10
    eyesx= xx+20
    eyesy= yy+10
    beyesx=xx+30
    beyesy= yy+15
    smilex= xx+5
    smiley= yy+60
    finx= xx+ 100
    finy= yy+ 50
    tailx= xx+ 185
    taily= yy+ 70 
    ball=s.create_oval(xx,yy,x2,y2, fill="orangered",outline="orangered")
    tail= s.create_polygon( tailx, taily, tailx+35, taily-35 , tailx+30, taily+50, fill="orangered")
    lines=s.create_line(linex+40,liney-10, linex+50,liney+100, fill="white",width=15)
    lines1= s.create_line(linex+65, liney-15, linex+80, liney+100, fill="white", width=15)
    eyes= s.create_oval(eyesx,eyesy, eyesx+40, eyesy+40, fill="white")
    beyes= s.create_oval(beyesx,beyesy, beyesx+20, beyesy+20, fill="black")
    smile= s.create_polygon(smilex, smiley, smilex+ 5,smiley+10, smilex+30, smiley+15, fill="black", width=6)
    fin= s.create_rectangle(finx, finy, finx+50, finy+20, fill="darkorange1", outline="darkorange1")
    wall= s.create_line(xwall,0, xwall,400, fill="grey", width=5)
    hook= s.create_line(100,400,110,405, fill="Grey",width=7)
    hook1= s.create_line(110,405,120,400, fill="Grey",width=7)
    hook2= s.create_line(120,400, 124,395, fill="grey",width=7)

    s.update()
    sleep(0.02)
    s.delete(ball,tail,lines,lines1,eyes,beyes,smile,fin)


spacing = 30#try changing this
for x in range(0, 1000, spacing): 
    s.create_line(x, 20, x, 1000, fill="yellow")
    s.create_text(x, 10, text=str(x), font="Times 10", anchor = N)


for y in range(0, 1000, spacing):
    s.create_line(30, y, 1000, y, fill="yellow")
    s.create_text(5, y, text=str(y), font = "Times 10", anchor = W, fill="yellow")

