from tkinter import *
from time import *
from math import *
from random import *

############################################################################
#################################STARRY NIGHT###############################
############################################################################
master = Tk()
s = Canvas( master, width = 600, height = 600, background = "midnightblue")
s.pack()
s.create_rectangle(0,390, 600,600, fill="darkslategray")
color= ["blue", "red", "green"]

##SUN##
s.create_oval(480,30,580, 100, fill="gold",outline="light goldenrod")
s.create_oval( 500,40,560,89, fill="yellow", outline="yellow")
s.create_oval(525,50, 560,85, fill="gold", outline="gold")



##OUTLINE OF MOUNTAINS##

s.create_polygon(0,360,60,370,70,390,0, 390, fill="black", width=2)
s.create_polygon(30, 390, 60, 385,100, 360,130,370,123, 390,60, 390,  fill="black", width=2)
s.create_polygon(210, 390, 240, 360,300, 345,330,330, 360, 330, 420,355,480,390, 180, 390, fill="black", width=2)
s.create_polygon(480, 390, 530, 360, 540,355,600, 350,600, 390, fill="black", width=2)



##HOUSES##

s.create_polygon(30,540,0,600,60,600, fill="pink")
s.create_polygon(30,540,0,540,0,600, fill="lightpink")

s.create_polygon(60,420,30,480,90,480, fill="grey")
s.create_polygon(60,420,30,420,0,460,30,480, fill="grey12")
s.create_rectangle(30,480,90,520, fill="grey",outline="grey")
s.create_polygon(0,450,30,480,30,520,0,520, fill="grey12")

s.create_polygon(600,420,540,420,510,440,570,450, fill="brown")
s.create_polygon(600,420,570,450,600,450, fill="sienna")
s.create_rectangle(570,450,600,510, fill="sienna",outline="sienna")
s.create_polygon(510,440,510,500,570,510,570,450, fill="brown")

s.create_polygon(420,420,390,470,450,470, fill="darksalmon")
s.create_polygon(420,420,450,420,473,460,450,470, fill="salmon")
s.create_polygon(450,470,450,510,470,510,470,460, fill="salmon")
s.create_rectangle(390,470,450,510, fill="darksalmon",outline="darksalmon")
#houses1

s.create_polygon(480,420,465,480,495,480, fill="grey")
s.create_polygon(480,420,510,420,525,470, 495,480,fill="grey20")
s.create_polygon(465,480,465,510,495,510,495,480, fill="Grey")
s.create_polygon(495,480,525,470,525,500,495,510, fill="grey20")

##houses2

s.create_polygon(300,540,270,600, 330,600, fill="steelblue1")
s.create_polygon(300,540,270,540,240,600,270,600, fill="steelblue3")

##house3

s.create_polygon(540,480,510,540, 570, 540, fill="lightblue3")
s.create_polygon(540,480, 570,480, 590,530, 570,540, fill="lightblue4")
s.create_polygon(570,540,590,530,590,560, 570,565, fill="lightblue4")


#whitehouse
s.create_polygon(315,410,345,450,360,480, 315, 450, fill="grey")

s.create_polygon(270, 480, 240, 450,305,400,315,450, fill="grey")

s.create_polygon(270,480,270, 510,300,510, 300,450, fill="white")
s.create_polygon(330,450,330,510,360,510,360,480,330, 450, fill="white")

s.create_polygon(300, 510,310,530,330, 530,335, 510,320, 510,  fill="white")
s.create_polygon(300,450, 300, 510,310,530,310,460, 300, 450, fill="grey")
s.create_polygon(310,460, 310,530,330,530,330, 460, 310,460, fill="grey")
s.create_polygon(330,460, 330,530,330,510,330,450, fill="grey")

s.create_polygon(300,450,310,460,330,460,330,450,315,360,300, 450,fill="rosybrown")
s.create_line(315,360, 310,460, fill="black")
s.create_line(315,360, 330,460, fill="black")


s.create_polygon(270,480,270,510,240,480,240,450,fill="grey")

s.update()
##TREE/BUSH##

s.create_polygon(30,600,60,540,60,520,70, 490,70,450,90,510,70,570,120,600,fill="dark olive green",outline="firebrick", smooth="true", width= 2)
s.create_polygon(120,600,110,570,120, 540, 130, 510,120, 480,132,450,125,390,140, 360, 150, 300, 165,250, 180, 360, 185, 390,180, 420, 176, 450, 157, 480, 180, 540, 180, 600, fill="dark olive green", outline="firebrick", smooth="true", width= 2)
s.create_polygon(90,600,90,570,93,540,100,510,95,480,90,450,90,420,120, 370,120,400,120, 480,130,520,140,540,123, 600, fill="dark olive green", outline="firebrick", smooth="true", width= 2)
s.create_polygon(90,600, 70,570,80,540,90, 500,100, 520,120, 570, 140, 600, fill="dark olive green",outline="firebrick", smooth="true", width= 2)
s.create_polygon(180,630,165,540,155,510,160,480,180,450,180,420,182,390,185,355,210,390,210,450,210,480,200,510,210, 600, fill="Dark olive green",outline="firebrick", smooth="true", width= 2)
s.create_polygon(210,600,200,540,213,480,220,450,230,520,240,570,240, 600, fill="dark olive green", outline="firebrick", smooth="true", width= 2)

for n in range(30):
    x = randint(240,260)
    y = randint(500,510)
    width = randint(10,15)
    height = randint(10,15)
    s.create_oval(x, y, x+width, y+height, fill="darkolivegreen", outline="darkolivegreen")

for n in range(30):
    x = randint(355,380)
    y = randint(500,510)
    width = randint(10,15)
    height = randint(10,15)
    s.create_oval(x, y, x+width, y+height, fill="darkolivegreen", outline="darkolivegreen")

##houses2

s.create_polygon(450,480,420,540,480,530, fill="khaki1")
s.create_polygon(420,540,420,600,480,570,480,530, fill="khaki2")
s.create_polygon(450,480,390,480,340,540,420,540, fill="wheat1")
s.create_rectangle(340,540,420, 600, fill="wheat1", outline="wheat1")


#cornerhouse

s.create_polygon(450, 600, 480, 540, 510,600,420, 600, fill="peru")
s.create_polygon(510,600, 480, 540, 570, 540, 600, 600, fill="dark khaki")




## SPIRALS## 
radius = 6
length = 2
theta = 20
rotationSpeed = .09

for f in range(150):

      xEnd = 100 + (radius+length)*cos(theta)
      yEnd = 100 - (radius+length+10)*sin(theta)

      xEnd1 = 300 + (radius+length)*cos(theta)
      yEnd1 = 150 - (radius+length)*sin(theta)
      xEnd2 = 500 + (radius+length)*cos(theta-30)
      yEnd2 = 160 - (radius+length)*sin(theta-30)
      xEnd3 = 500 + (radius+length)*cos(theta-20)
      yEnd3 = 260 - (radius+length)*sin(theta-30)
      xEnd4 = 180 + (radius+length)*cos(theta-10)
      yEnd4 = 210 - (radius+length)*sin(theta-10)
      xEnd5 = 200 + (radius+length+10)*cos(theta)
      yEnd5 = 120 - (radius+length+10)*sin(theta)
      xEnd6 = 100 + (radius+length+1)*cos(theta-50)
      yEnd6 = 300 - (radius+length+1)*sin(theta-50)
      xEnd7 = 300 + (radius+length+1)*cos(theta-50)
      yEnd7 = 210 - (radius+length+1)*sin(theta-50)
      xEnd8 = 420 + (radius+length+1)*cos(theta-50)
      yEnd8 = 270 - (radius+length+1)*sin(theta-50)
      xEnd9 = 420 + (radius+length+1)*cos(theta-30)
      yEnd9 = 150 - (radius+length+1)*sin(theta-30)
      xEnd10= 270 + (radius+length+1)*cos(theta-10)
      yEnd10= 280 - (radius+length+1)*sin(theta-10)
      xEnd11= 90 + (radius+length+1)*cos(theta-90)
      yEnd11= 210 - (radius+length+1)*sin(theta-90)
      xEnd12= 350 + (radius+length+1)*cos(theta-90)
      yEnd12= 60 - (radius+length+1)*sin(theta-90)
      xEnd13= 350 + (radius+length-3)*cos(theta-90)
      yEnd13= 300 - (radius+length-3)*sin(theta-90)
      
      laser = s.create_line(  xEnd, yEnd, xEnd+10, yEnd+10,fill="steelblue", width=1)
      laser1 = s.create_line(  xEnd1, yEnd1, xEnd1+10, yEnd1+10,fill="cadetblue1", width=1)
      laser1 = s.create_line(  xEnd1, yEnd1, xEnd1+5, yEnd1+5,fill="dodgerblue2", width=1)
      laser2 = s.create_line(  xEnd2, yEnd2, xEnd2+5, yEnd2+5,fill="deepskyblue", width=1)
      laser2 = s.create_line(  xEnd2, yEnd2, xEnd2+5, yEnd2+5,fill="deepskyblue", width=1)      
      laser3 = s.create_line(  xEnd3, yEnd3, xEnd3+10, yEnd3+10,fill="cornflowerblue", width=1)      
      laser4 = s.create_line(  xEnd4, yEnd4, xEnd4+10, yEnd4+10,fill="turquoise1", width=1)      
      laser5 = s.create_line(  xEnd5, yEnd5, xEnd5+10, yEnd5+10, fill="blue2", width=1)      
      laser5 = s.create_line(  xEnd5, yEnd5, xEnd5+5, yEnd5+5, fill="lightblue3", width=1)
      laser6 = s.create_line(  xEnd6, yEnd6, xEnd6+7, yEnd6+7, fill="blue", width=1)
      laser7 = s.create_line(  xEnd7, yEnd7, xEnd7+7, yEnd7+7, fill="snow", width=1)
      laser8 = s.create_line(  xEnd8, yEnd8, xEnd8+5, yEnd8+5, fill="blue", width=1)
      laser9 = s.create_line(  xEnd9, yEnd9, xEnd9+10, yEnd9+11, fill="powderblue", width=1)
      laser10 = s.create_line(  xEnd10, yEnd10, xEnd10+10, yEnd10+11, fill="darkslateblue", width=1)
      laser11 = s.create_line(  xEnd11, yEnd11, xEnd11+10, yEnd11+11, fill="mediumslateblue", width=1)
      laser12 = s.create_line(  xEnd12, yEnd12, xEnd12+10, yEnd12+11, fill="deepskyblue", width=1)
      laser13 = s.create_line(  xEnd13, yEnd13, xEnd13+10, yEnd13+11, fill="darkcyan", width=1)





      theta = theta + rotationSpeed
      radius= radius+0.2

      s.update()
      sleep(.03)

   




    




spacing = 30#try changing this
for x in range(0, 1000, spacing): 
    s.create_line(x, 20, x, 1000, fill="yellow")
    s.create_text(x, 10, text=str(x), font="Times 10", anchor = N)


for y in range(0, 1000, spacing):
    s.create_line(30, y, 1000, y, fill="yellow")
    s.create_text(5, y, text=str(y), font = "Times 10", anchor = W, fill="yellow")
