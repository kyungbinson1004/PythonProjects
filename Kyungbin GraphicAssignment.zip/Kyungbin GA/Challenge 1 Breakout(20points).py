from tkinter import *
from time import *

tk = Tk()
s = Canvas(tk, width=800, height=800, background="pink")
s.pack()


#INITIAL VALUES
x1 = 250
y1 = 350

xSpeed = 5
ySpeed = 5

diameter = 70
length= 200
rectanglex= 250
rectangley= 300
rectanglex2= rectanglex + length
rectangley2= rectangley+ length
   

#ANIMATION LOOP


for f in range(100000): 

    x1 = x1 + xSpeed  
    y1 = y1 + ySpeed
    
    x2 = x1 + diameter
    y2 = y1 + diameter
 

    #print("In frame", f, "x2 is", x2)
    
    if x2 >rectanglex2:#why doesn't this work when xSpeed is 11?
        xSpeed = -1 * xSpeed
        rectanglex2= rectanglex2+20
        


    if x1<rectanglex:
        xSpeed= -1 *xSpeed
        rectanglex= rectanglex-20



    if y2 >rectangley2:  
        ySpeed = -1 * ySpeed
        rectangley2= rectangley2+20 
        


    if y1<rectangley:
        ySpeed=-1 *ySpeed
        rectangley= rectangley-20

    #Create the objects 
    ball = s.create_oval(  x1,  y1,  x2,  y2,  fill="light blue", outline= "light blue")
    rectangle= s. create_rectangle(rectanglex, rectangley, rectanglex2, rectangley2, outline="yellow")

    #Draw the balls in their current position
    s.update()

    #Slow down the animation so the human eye can see it.
    sleep(0.03)

    #Delete old objects
    s.delete( ball,rectangle)

   

