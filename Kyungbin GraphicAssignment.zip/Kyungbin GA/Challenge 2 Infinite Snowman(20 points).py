from tkinter import *
from time import *
from math import *
from random import *


master = Tk()
s = Canvas( master, width = 700, height = 700, background = "midnightblue")
s.pack()


diameter= int(input("What is the diameter of the bottom snowball?"))
percentage= int(input("What is the percentage you want to shrink it by?"))
percentageDec= percentage/100
x= 350
y= 700
r= diameter/2
x1= x-r
y1= y- diameter
x2= x1+diameter
y2= y1+diameter
s.create_oval(x1,y1,x2,y2, fill="green")
while diameter>2:
    diameter= diameter -diameter*percentageDec
    r=diameter/2
    y2=y1
    x1= x-r
    y1= y1- diameter
    x2= x1+diameter
    s.create_oval(x1,y1,x2,y2, fill="green")
        
s.update()
    
    
