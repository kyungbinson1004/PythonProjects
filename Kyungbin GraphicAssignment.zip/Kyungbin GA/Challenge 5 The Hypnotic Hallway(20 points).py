from tkinter import *
from time import *

master = Tk()
s = Canvas( master, width = 1000, height = 1000, background = "black")
s.pack()

direction= "right"
x1=500
y1=500
length =10
gap = 4

while x1 < 1000:
      if direction == "right":
            x2=x1+length
            y2 = y1
            direction = "up"
            colour = "yellow"
      elif direction == "up":
            x2 = x1
            y2=y1-length
            direction = "left"
            colour = "blue"
      elif direction == "left":
            x2=x1-length
            y2=y1
            direction="down"
            colour = "red"
      else:
            x2=x1
            y2=y1+length
            direction="right"
            colour = "green"

      s.create_line(x1,y1,x2,y2,fill=colour)
      s.update()
      sleep(0.06)
      length = length+gap
      x1=x2
      y1=y2
      
