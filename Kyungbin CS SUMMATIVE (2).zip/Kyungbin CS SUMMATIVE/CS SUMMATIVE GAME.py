from tkinter import *
from random import *
from time import *
from math import*
root = Tk()
screen = Canvas(root, width=2000, height=2000, background= "white")

root = Tk()
backgroundstuff= PhotoImage(file= "wood2.gif")
screen.create_image(680, 580, image = backgroundstuff)
gameMode=0
level = 1

###INITAL VALUES: THIS INCLUDES ALL THE VALUES THAT I WILL BE USING IN OTHER DEFS FOR EXAMPLE, SCORE, XMOUSE. ###
def setInitialValues():
    global final,easyintroo,hardintroo,mediumintroo,gameoverr,leveldisplay,health,difficultyBackground,level,bar1,bar,squashed,hammer,gameMode,hammer1,score,game,xMouse,startgame,image,xSpeed,yMouse,ySpeed,group, numBugs,xValue,yValue, numbugs, hammer1, bugg,WIDTH, HEIGHT,TICK_SPEED,TICK_DELAY, BUG_SPAWN_PERIOD,BUG_SPAWN_SPEED,BUG_VELOCITY, BUG_SPAWN_SPEED, BUG_VELOCITY,BUG_RADIUS
    global bloodSpeedx,text2, squashedd,bloodSpeedy, bloodx, bloody,blood1,blood2,numbloods,bees,numBees,bee, beeX, beeY, beeXspeed, beeYspeed
    global bee,scores,lives,score,buggroup,gameover,instructions,lifeimage,onelife,hplevel,twolife,threelife,beeGroup,twoclicksbug,twoclicks,bugX,bugY,numTwoClicks,bugSpeedX,bugSpeedY,squasheddd
    if level == 1:
        score=0
        scores=0 
    instructions= PhotoImage(file="i.gif")
    squashed = 0
    final= 0
    hammer= PhotoImage(file="abc.gif")
    blood1= PhotoImage(file="blood2.gif")
    hammer1=0
    easyintroo= PhotoImage(file="easyintro.gif")
    mediumintroo= PhotoImage(file="mediumintro.gif")
    hardintroo= PhotoImage(file="hardintro.gif") 
    buggroup=[]
    text2=0
    bloodx= []
    bloody= []
    bloodSpeedx= []
    bloodSpeedy= [] 
    bugg= PhotoImage(file= "ladybug.gif")
    bugCounter= 0
    numBugs=10
    xValue= []
    bugX= []
    bugY= []
    bugSpeedY= []
    bugSpeedX=[]
    numTwoClicks= 6
    yValue=[]
    ySpeed= []
    xSpeed= []
    xMouse=0
    yMouse=0
    group= []
    beeGroup= []
    game= 0
    squashedd= 0
    startgame= PhotoImage(file= "EASY.gif")
    bar = 1350
    bar1 = 0
    leveldisplay = 0
    lives= 3 
    difficultyBackground= PhotoImage(file="Untitled_design.gif") 
    numbloods=2
    health= 2 
    bees= PhotoImage(file= "bees.gif")
    onelife= PhotoImage(file="one.gif")
    twolife=PhotoImage(file="two.gif")
    threelife=PhotoImage(file="three.gif")
    twoclicksbug= PhotoImage(file="bug22.gif")
    hplevel=[]
    squasheddd=0
    twoclicks=[]
    numBees= 10
    bee= []
    beeX= []
    beeY= []
    beeXspeed= []
    beeYspeed= []
    gameoverr=PhotoImage(file="gameover.gif")

    
###SETTING X AND Y VALUES FOR BEES###
    for i in range(0, numBees):
        beePositionX= randint(100,1300)
        beeX.append(beePositionX)
        beePositionY= randint(250,650)
        beeY.append(beePositionY)
        beeXspeedd= randint(-7,7)
        beeXspeed.append(beeXspeedd)
        beeYspeedd= randint(-2,2)
        beeYspeed.append(beeYspeedd)


##SETTING X AND Y VALUE FOR BEETLES## 
    for i in range(0, numTwoClicks):
        bugxx= randint(100,1300)
        bugX.append(bugxx)
        bugyy= randint(250,650)
        bugY.append(bugyy)
        bugSpeedxx= randint(-5,5)
        bugSpeedX.append(bugSpeedxx)
        bugSpeedyy= randint(-2,2)
        bugSpeedY.append(bugSpeedyy)
        hplevel.append(2)


###SETTING X AND Y VALUES FOR BUGS###      
    for i in range(0, numBugs):
        xPos= randint(100,1300)
        xValue.append(xPos)
        yPos= randint(250, 650)
        yValue.append(yPos)
        ySpeedd= randint(-2,2)
        ySpeed.append(ySpeedd)
        xSpeedd= randint(-5,5)
        xSpeed.append(xSpeedd)

        
##FOR THE MOUSE TO BE DETECTED###
def mouseMotionDetector( event ):
    global xMouse,yMouse
    xMouse= event.x
    yMouse= event.y
    drawFinger()

###DRAWS FINGER AS MOUSE###   
def drawFinger():
    global hammer1,hammer
    screen.delete(hammer1)
    hammer1= screen.create_image(xMouse+50, yMouse+160, image= hammer)

###DRAWS THE BUGS###
def drawBugs():
    global yValue,ySpeed, numBugs, xValue,bug,xSpeed,bar,bar1,group,leveldisplay,score
    for i in range(0,numBugs):
        if 0 < xValue[i]:
            xSpeed[i] = -xSpeed[i]
        if 350 < yValue[i]:
            ySpeed[i] = -ySpeed[i]
        if 1350 > xValue[i]:
            xSpeed[i] = -xSpeed[i]
        if 600 > yValue[i]:
            ySpeed[i] = -ySpeed[i]
        yValue[i]= yValue[i]+ySpeed[i]
        xValue[i]= xValue[i]+xSpeed[i]
        bug= screen.create_image(xValue[i], yValue[i], image= bugg)
        group.append(bug)
    screen.delete(bar1)
    bar1 = screen.create_rectangle(0,0,bar,50, fill = "red")
    screen.delete(leveldisplay)
    leveldisplay= screen.create_text( 150,100 , text = "LEVEL"+str(level), fill = "red", font = "Times 40")
 

###DRAWING THE BEES### 
def drawBees():
    global beeXspeed,beeX, numBees, beeY, beeYspeed, bees,bar,bar1,beeGroup
    for i in range(0,numBees):
        if 0 < beeX[i]:
            beeXspeed[i] = -beeXspeed[i]
        if 350 < beeY[i]:
            beeYspeed[i] = -beeYspeed[i]
        if 1350 > beeX[i]:
            beeXspeed[i] = -beeXspeed[i]
        if 600 > beeY[i]:
            beeYspeed[i] = -beeYspeed[i]
        beeY[i]= beeY[i]+beeYspeed[i]
        beeX[i]= beeX[i]+beeXspeed[i]
        bee= screen.create_image(beeX[i], beeY[i], image= bees)
        beeGroup.append(bee)

## THIS DRAWS THE BEETLES##
## IT DETECTS IF IT HIT THE BOUNDARIES, AND MAKES IT BOUNCE BACK BY PUTTING A NEGATIVE SPEED## 
def drawTwoClicks():
    global bugSpeedX,bugSpeedY, bugX, bugY, bugs,buggroup,hplevel
    for i in range(0,numTwoClicks):
        if 0 < bugX[i]:
            bugSpeedX[i] = -bugSpeedX[i]
        if 350 < bugY[i]:
            bugSpeedY[i] = -bugSpeedY[i]
        if 1350 > bugX[i]:
            bugSpeedX[i] = -bugSpeedX[i]
        if 600 > bugY[i]:
            bugSpeedY[i] = -bugSpeedY[i]
        bugX[i]= bugX[i]+bugSpeedX[i]
        bugY[i]= bugY[i]+bugSpeedY[i]
        bugs= screen.create_image(bugX[i], bugY[i], image= twoclicksbug)
        
        buggroup.append(bugs)
        
        
###DELETES THE BUGS###      
def deleteBugs():
    global group, numBugs, squashed
    for i in range(0, numBugs+squashed):
        screen.delete(group[i])
    squashed = 0
    group = []
    
###DELETES THE BEES### 
def deleteBees():
    global numBees,squashedd,beeGroup
    for i in range(0,numBees+squashedd):
        screen.delete(beeGroup[i])
    squashedd =0
    beeGroup=[]

## THIS DELETES THE BEETLES BY DELETING THE ARRAY OF IT##
def deleteTwoClicks():
    global numTwoClicks,squasheddd,buggroup
    for i in range(0,numTwoClicks+squasheddd):
        screen.delete(buggroup[i])
    squasheddd=0
    buggroup=[]

## THIS RUNS THE GAME FOR EASY MODE##    
def runGame():
    global gameMode,bar,lives,easyintroduction
    if gameMode == 0:
        gameMode = 1    
        setInitialValues()
        easyIntro()
    while bar>0:
        drawFinger()
        drawBugs()
        screen.update()
        sleep(0.03)
        deleteBugs()
        barHandler()
    gameover()
        

##THIS IS THE TIME LIMIT BAR FOR THE EASY AND MEDIUM MODE##
##THIS RECTANGLE SLOWLY DECREASES AS THE LEVELS ARE INCREASING## 
def barHandler():
    global bar,level,leveldisplay,numBugs,text2
    bar -= level
    screen.delete(bar1)
    screen.delete(leveldisplay)
    if numBugs< 1:
        level += 1
        setInitialValues()
    if bar < 0:
        root.destroy()
        gameMode=2 
        screen.bind("<Button-1>", goBackScreen)
        text2= screen.create_text(650, 500, text= "FINAL SCORE"+str(score),fill="red",font="Times 100")
       
## THIS IS THE TIME BAR FOR THE HARD MODE. I MADE ONE SEPARATELY FOR THE HARD MODE BECAUSE I ALSO HAD TO DETECT THE NUMBER OF CLICKS
## AS I NEED TO CHECK THE NUMBER OF CLICKS FOR THE BEETLES
def barHandlerTwo():
    global bar,level,leveldisplay,numBugs,gameover,score,bar1,gameMode,scores,text2
    bar -= level
    screen.delete(bar1)
    screen.delete(leveldisplay)

    if numBugs< 1 and numTwoClicks<1:
        level += 1
        setInitialValues()
    
    if bar < 0:
        root.destroy()
        gameMode=2 
        screen.bind("<Button-1>", goBackScreen)
        text2= screen.create_text(650, 500, text= "FINAL SCORE"+str(score),fill="red",font="Times 100")
       
##DRAWS THE BLOOD WHERE THE FINGER IS WHEN IT IS IN THE BOUNDARIES OF THE BUG##     
def drawBlood():
    global xValue,yValue, blood1,xSpeed,ySpeed,xMouse,yMouse,scores,score
    for i in range(0,numBugs):
        yValue[i]= yValue[i]+ySpeed[i]
        xValue[i]= xValue[i]+xSpeed[i]
        bloodd= screen.create_image(xMouse+50, yMouse+10, image= blood1)
    score= score+1
    screen.delete(scores)
    scores= screen.create_text(700, 100, text= "NUMBER OF KILLING="+" "+str(score), fill="red",font= "Helvetica 40")

## THIS IS ONE OF THE MAIN EVENTS I USE##
## THIS DETECTS THE DIFFICULTIES, INSTRUCTION PAGE IN THE BEGINNING##
## ALSO DETECTS IF THE MOUSE IS IN THE BOUNDARIES OF THE BUG, BEETLES AND THE BEES## 
def mouseClickHandler( event ):
    global squashed,xMouse, lives,yMouse,xValue,yValue,numBugs,bloodx,bloody,bloodSpeedx,bloodSpeedy,xSpeed,ySpeed,score,gameMode,beeX,beeY,squashed
    global numTwoClicks, bugX,bugY,bugSpeedX,bugSpeedY,squasheddd,hplevel,instructionPage
    xMouse = event.x 
    yMouse = event.y
## I MADE A GAME MODE FOR WHEN WHEN THE GAME HAS JUST STARTED AND IT LEADS TO THE DIFFICULTIES OR INSTRUCTIONS PAGE##
## GAME MODE IS SET AT ONE IN RUN GAME## 
    if gameMode == 0:
        if 300<= xMouse<= 1500 and 400<= yMouse <=600:
            difficulties()

        if 300<= xMouse<=1500 and 650<= yMouse<= 1000:
            instructionPage()

## GAME MODE IS SET TO 0 WHEN THE TIME IS AT 0, THEREFORE THIS IF STATEMENT ONLY WORKS WHEN THE GAME IS OVER## 
    if gameMode== 2:
        if 0<= xMouse<= 2000 and 0<= yMouse <=2000:
            startingScreen()
            
## IF IT IS IN THE BOUNDARIES OF THE BUGS, THEN IT DELETES THE BUGS AND DRAWS BLOOD##
    else:
        for i in range(0,numBugs):
            if xMouse >=xValue[i] - 50 and xMouse <=xValue[i] + 50 and yMouse>=yValue[i]-50 and yMouse<=yValue[i] + 50:
                
                screen.delete(group[i])
                drawBlood()
                
                del xValue[i]
                del yValue[i]
                del xSpeed[i]
                del ySpeed[i]
                numBugs -=1
                squashed = 1
                
##IF IT IS IN THE BOUNDARIES OF THE BEETLES IN HARD MODE, THEN THE USER HAS TO CLICK IT TWICE, AS I FIRST SET THE HPLEVEL AS TWO##
## IN THE BEGINNING AND NOW WHEN IT IS CLICKED ONCE, THE IT DELETES ONLY ONE##
## THIS MAKES IT HARDER FOR USERS## 
        for i in range(0,numTwoClicks):
            if xMouse >=bugX[i] - 50 and xMouse <=bugX[i] + 50 and yMouse>=bugY[i]-50 and yMouse<=bugY[i] + 50: 
                hplevel[i]-=1
                if hplevel[i]<=0:
                    drawBlood()
                    del bugX[i]
                    del bugY[i]
                    del bugSpeedX[i]
                    del bugSpeedY[i]
                    numTwoClicks -=1
                    squasheddd = 1

## IF IT IS IN THE BOUNDARIES OF THE BEES IN MEDIUM MODE, THEN THE USER LOSES A LIFE##
        for i in range(0,numBees):
            if xMouse >= beeX[i] - 50 and xMouse <=beeX[i] + 50 and yMouse>=beeY[i]-50 and yMouse<=beeY[i] + 50:
                lives= lives-1 


##THIS IS THE DIFFICULTY BACKGROUND##    
def difficulties():
    global difficultyBackground
    difficulty= screen.create_image(680,380, image=difficultyBackground)
    screen.bind("<Button-1>", difficultyScreenHandler)


##THIS IS WEHRE IT DETECTS WHAT MODE THE PLAYER CHOSE TO PLAY##
## THERE ARE BOUNDARIES FOR EACH MODE THAT THE MOUSE IS DETECTED FOR## 
def difficultyScreenHandler(event):
    global xMouse,yMouse

    if 300<=xMouse<=1500 and 100<= yMouse<=350:
        screen.bind("<Button-1>", mouseClickHandler)
        easyButton()

    if 300<=xMouse<=1500 and 400<=yMouse<= 700:
        screen.bind("<Button-1>", mouseClickHandler)
        mediumButton()
        
    if 300<=xMouse<=1500 and 550<=yMouse<= 850:
        screen.bind("<Button-1>", mouseClickHandler)
        hardButton()

##THIS IS THE STARTING SCREEN FOR THE GAME##
##FROM HERE, THE PLAYER EITHER CHOOSES THE INSTRUCTIONS OR THE DIFFICULTIES## 
def startingScreen():
    global startgame, background

    setInitialValues()

    background= screen.create_image(680,380, image= startgame)
    screen.bind("<Button-1>",mouseClickHandler)

## THIS IS THE SHORT INTRO SCREEN FOR EASY MODE WHEN IT IS CLICKED##
def easyIntro():
    global easyintroo
    easyintroduction= screen.create_image(680,380, image=easyintroo)
    screen.update()
    sleep(4)
    screen.delete(easyintroduction)
    screen.update()
    
## THIS IS THE SHORT INTRO SCREEN FOR MEDIUM MODE WHEN IT IS CLICKED##
def mediumIntro():
    global mediumintroo
    mediumintroduction= screen.create_image(680,380, image= mediumintroo)
    screen.update()
    sleep(4)
    screen.delete(mediumintroduction)
    screen.update()

## THIS IS THE SHORT INTRO SCREEN FOR HARD MODE WHEN IT IS CLICKED##
def hardIntro():
    global hardintroo
    hardintroduction= screen.create_image(680,380, image= hardintroo)
    screen.update()
    sleep(4)
    screen.delete(hardintroduction)
    screen.update()
    
## THIS DRAWS THE LIVES IN THE MEDIUM MODE WHEN THE MOUSE IS IN CONTACT WTIH THE BEES##
def drawLives():
    global lives, lifeimage
    if lives==3:
        lifeimage= screen.create_image(800,380, image= threelife)

    elif lives ==2:
        lifeimage=screen.create_image(700,380, image=twolife)

    elif lives==1:
        lifeimage= screen.create_image(700,380, image=onelife)

## THIS DELETES THE LIVES WHEN IT IS WHEN THE MOUSE IS IN CONTACT WITH THE BEES##
def deleteLives():
    global lifeimage
    screen.delete(lifeimage)


## THIS IS THE RUNGAME FOR THE EASYMODE##
def easyButton():
    runGame()

## THIS IS THE RUNGAME FOR THE MEDIUMMODE##
def mediumButton():
    global gameMode,bar,lives,gameover
    if gameMode == 0:
        gameMode = 1
        setInitialValues()
        mediumIntro()
    while lives>0:
        drawLives()
        drawFinger()
        drawBugs()
        drawBees()
        screen.update()
        sleep(0.03)
        deleteBugs()
        deleteLives()
        deleteBees()
        barHandler()
    gameover()

## THIS IS CALLED WHEN THE TIME LIMIT IS AT 0 BUT NOT ALL OF THE BUGS ARE ELIMINATED##
def gameover():
    global final
    screen.create_image(680,300, image=gameoverr)
    screen.delete(final)
    final=screen.create_text(700, 100, text= "YOUR FINAL SCORE IS" + " "+str(score), fill="black",font= "Helvetica 70")

    screen.bind("<Button-1>", goBackScreen)

    
## THIS IS THE RUNGAME FOR THE HARDMODE, I MADE IT SEPARATELY SO I CAN CHANGE IT MORE EASILY##
def hardButton():
    global gameMode,bar,lives
    if gameMode == 0:
        gameMode = 1
        setInitialValues()
        hardIntro()
    while bar>0: 
        drawFinger()
        drawBugs()
        drawTwoClicks()
        screen.update()
        sleep(0.03)
        deleteBugs()
        deleteTwoClicks()
        barHandlerTwo()
    gameover()
  
## THIS GIVES THE INSTRUCTIONS WHEN THE INSTRUCTIONS IS CLICKED FROM THE MOUSECLICK HANDLER##
## IN THE INSTRUCTIONS PAGE, WHEN U CLICK BACK IT WILL RESULT BACK TO THE HOMESCREEN DUE TO THE GOBACKSCREEN(EVENT)##
def instructionPage():
    global instructions,instructionpagee

    setInitialValues()

    instructionpagee= screen.create_image(680,340, image= instructions)
    screen.bind("<Button-1>",goBackScreens)


##THIS IS CALLED WHEN THE USER CLICKS THE START OVER BUTTON SO THE USER CAN GO BACK TO THE HOME SCREEN##
def goBackScreens(event):
    global xMouse,yMouse

    if 0<=xMouse<=2000 and 0<= yMouse<=2000:
        startingScreen()

    
##AFTER THE GAME IS OVER, WHEN THE USER CLICKS THE 'START OVER' AND IT WILL RESULT BACK TO THE STARTING SCREEN##
def goBackScreen(event):
    global xMouse,yMouse,gameMode,final,scores,text2,score,level
    level=1
    score=0
    screen.delete(final)
    screen.delete(text2)
    screen.delete(scores)
    if 0<=xMouse<=2000 and 0<= yMouse<=2000:
        gameMode=0
        startingScreen()


root.after(0, startingScreen)## THIS TELLS THE PROGRAM TO BEGIN AT THE DEF STARTING SCREEN##
screen.bind( "<Motion>", mouseMotionDetector) ## IT BINDS THE MOUSE MOTION##
screen.bind("<Button-1>", mouseClickHandler)## THIS DETECTS THE MOUSE CLICKING##
screen.pack() #PUTS THE SCREEN TOGETHER
screen.focus_set()

root.mainloop()

