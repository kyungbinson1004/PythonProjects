from random import *

def getMove( myScore, myBalls, myDucksUsed, myMovesSoFar,
             oppScore, oppBalls, oppDucksUsed, oppMovesSoFar ):    
    #Creating the Arrays 
    movesWithoutDucks = ["RELOAD", "THROW"]
    movesWithoutThrows = ["RELOAD", "DUCK"]
    movesWithoutReload = ["THROW", "DUCK"]
    moves = ["RELOAD", "THROW", "DUCK"]

    #The first move
    if len(myMovesSoFar) == 0:
        return "RELOAD"

    elif len(myMovesSoFar) == 1: 
        return "RELOAD"

    #Conditions that are definite
    if myBalls == 0 and oppBalls == 0: ##IF WE BOTH GOT NO BALLS, WE RELOAD
        return "RELOAD"

    elif myBalls >= 1 and oppBalls == 0 and oppDucksUsed == 5 : ## IF WE GOT BALLS AND THE OPP HAS NO BALLS AND NO DUCKS, WE THROW
        return "THROW"

    elif oppScore == 2: ### IF THE OPP SCORE IS 2, CHECK THESE STATEMENTS
        if myBalls >= 1: ### IF WE GOT ONE OR MORE BALLS, CHECK THESE STATEMENTS
            if myDucksUsed < 5: ### IF WE GOT SOME DUCKS LEFT WE PICK FROM THE ARRAY THAT HAS ONLY THROW OR DUCK
                return choice(movesWithoutReload)

            else: ### IF WE GOT NO DUCKS LEFT, WE THROW
                return "THROW"

        else: ### IF WE DONT GOT BALLS, CHECK THESE STATEMENTS
            if myDucksUsed < 5: ### IF WE GOT DUCKS LEFT, WE DUCK
                return "DUCK"

            else: ###IF WE DON'T GOT DUCKS LEFT, WE RELOAD
                return "RELOAD"

    elif myBalls >= 5: ### IF WE GOT MORE THAN 5 BALLS, WE THROW
        return "THROW"

    elif myMovesSoFar[len(myMovesSoFar)- 1 ] == "DUCK" and myMovesSoFar[len(myMovesSoFar)- 2 ] == "DUCK": ### IF OUR LAST 2 MOVES WERE DUCK, CHECK THESE STATEMENTS
        if myBalls >= 1: ### IF WE GOT BALLS, CHOOSE FROM THE ARRAY THAT DOESN'T HAVE DUCK AS AN OPTION
            return choice(movesWithoutDucks)

        else: ### IF WE DONT GOT BALLS, WE RELOAD
            return "RELOAD"
            
    #Determining move when opponent's last move was "RELOAD"
    elif oppMovesSoFar[len(oppMovesSoFar)-1] == "RELOAD": ### IF THE LAST MOVE WAS RELOAD, MAKE THE CHANCE OF 'DUCK' HIGHER IN ALL THE ARRAYS (EXCEPT movesWithoutDucks)
        moves.append("DUCK")
        movesWithoutThrows.append("DUCK")
        movesWithoutReload.append("DUCK")
        if myBalls >= 1 : ###IF WE GOT BALLS, CHECK THESE STATEMENTS
            if myDucksUsed < 5: ### IF WE GOT DUCKS, PICK FROM THE ARRAY WITH ALL THE MOVES IN IT
                return choice(moves)
            
            else: ### IF WE DON'T GOT DUCKS, PICK FROM THE ARRAY WITH NO DUCKS
                return choice(movesWithoutDucks)

        else: ### IF WE DON'T GOT BALLS, CHECK THESE STATEMENTS
            if myDucksUsed < 5: ### IF WE GOT DUCKS, PICK FROM THE ARRAY THAT HAS NO THROWS
                return choice(movesWithoutThrows)

            else: ### IF ALL ELSE FAILS, RELOAD
                 return "RELOAD"
                 
    #Determining move when opponent's last move was "THROW"
    elif oppMovesSoFar[len(oppMovesSoFar)-1] == "THROW": ### IF THE LAST MOVE WAS RELOAD, MAKE THE CHANCE OF 'THROW' HIGHER IN ALL THE ARRAYS (EXCEPT movesWithoutThrows)
        moves.append("RELOAD")
        movesWithoutDucks.append("RELOAD")
        movesWithoutThrows.append("RELOAD")
        if myBalls >= 1 : ###IF WE GOT BALLS, CHECK THESE STATEMENTS
            if myDucksUsed < 5: ### IF WE GOT DUCKS, PICK FROM THE ARRAY WITH ALL THE MOVES IN ITK
                return choice(moves)
            
            else:### IF WE DON'T GOT DUCKS, PICK FROM THE ARRAY WITH NO DUCKS
                return choice(movesWithoutDucks)

        else:### IF WE DON'T GOT BALLS, CHECK THESE STATEMENTS
            if myDucksUsed < 5: ### IF WE GOT DUCKS, PICK FROM THE ARRAY THAT HAS NO THROWS
                return choice(movesWithoutThrows)

            else: ### IF ALL ELSE FAILS, RELOAD
                 return "RELOAD"

    #Determining move when opponent's last move was "DUCK"
    elif oppMovesSoFar[len(oppMovesSoFar)-1] == "DUCK":
        moves.append("THROW")
        movesWithoutDucks.append("THROW")
        movesWithoutReload.append("THROW")
        if myBalls >= 1 : ###IF WE GOT BALLS, CHECK THESE STATEMENTS
            if myDucksUsed < 5: ### IF WE GOT DUCKS, PICK FROM THE ARRAY WITH ALL THE MOVES IN IT
                return choice(moves)
            
            else:  ### IF WE DON'T GOT DUCKS, PICK FROM THE ARRAY WITH NO DUCKS
                return choice(movesWithoutDucks)

        else:### IF WE DON'T GOT BALLS, CHECK THESE STATEMENTS
            if myDucksUsed < 5: ### IF WE GOT DUCKS, PICK FROM THE ARRAY THAT HAS NO THROWS
                return choice(movesWithoutThrows)

            else: ### IF ALL ELSE FAILS, RELOAD
                 return "RELOAD"



    

    
    
    
        
